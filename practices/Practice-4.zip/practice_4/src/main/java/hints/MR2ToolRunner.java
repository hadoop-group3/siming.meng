package hints;

import java.io.IOException;
import java.util.Calendar;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * TODO To implement this class as a Tool for ToolRunner:
 *
 * extend Configured and implement Tool
 */
public class MR2ToolRunner {

	public static class AverageReducer extends Reducer<Text, IntWritable, Text, DoubleWritable> {

		@Override
		public void reduce(Text key, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {

			long sum = 0, count = 0;

			for (IntWritable value : values) {
				sum += value.get();
				count++;
			}

			if (count != 0) {
				double result = (double) sum / (double) count;
				context.write(key, new DoubleWritable(result));
			}
		}
	}

	public class LetterMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

		/*
		 * TODO: Define a boolean variable indicate whether to do case sensitive
		 * processing.
		 */

		/**
		 * The map method runs once for each line of text in the input file. The
		 * method receives:
		 * 
		 * @param A
		 *            key of type LongWritable
		 * @param A
		 *            value of type Text
		 * @param A
		 *            Context object.
		 */
		@Override
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

			String line = value.toString();

			for (String word : line.split("\\W+")) {
				if (word.length() > 0) {

					/*
					 * TODO: check the value of the caseSensitive variable. If
					 * false, convert all letters to lower case. Otherwise,
					 * leave them mixed case. Hint: use the String.toLowerCase()
					 * method
					 */

					String letter = word.substring(0, 1);
					context.write(new Text(letter), new IntWritable(word.length()));
				}
			}
		}

		/*
		 * @override public void setup(Context context) {
		 */
		/*
		 * TODO: Override the setup() method to check the value of the a
		 * parameter called caseSensitive and set a member variable to track
		 * whether to do case sensitive handling of letters.
		 */

		/*
		 * }
		 */
	}

	/**
	 * TODO convert the main method into a run method with signature:
	 *
	 * public int run(String[] args) throws Exception {
	 *
	 * TODO Create a new main method that calls the run method.
	 *
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		if (args.length != 2) {
			System.out.printf("Usage: Provide <input dir> <output dir>\n");
			System.exit(-1);
		}

		Job job = Job.getInstance();
		job.setJarByClass(MR2ToolRunner.class);
		job.setJobName("Average Word Length");

		// setup input and output
		FileInputFormat.setInputPaths(job, new Path(args[0]));
		// note, this creates a new output path using the time of creation
		String output = args[1] + "_" + Calendar.getInstance().getTimeInMillis();
		FileOutputFormat.setOutputPath(job, new Path(output));
		/*
		 * Specify the mapper and reducer classes.
		 */
		job.setMapperClass(LetterMapper.class);
		job.setReducerClass(AverageReducer.class);

		/*
		 * The mapper's output keys and values have different data types than
		 * the reducer's output keys and values. Therefore, you must call the
		 * setMapOutputKeyClass and setMapOutputValueClass methods.
		 */
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);

		/*
		 * Specify the job's output key and value classes.
		 */
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(DoubleWritable.class);

		/*
		 * Start the MapReduce job and wait for it to finish. If it finishes
		 * successfully, return 0. If not, return 1.
		 */
		boolean success = job.waitForCompletion(true);
		System.exit(success ? 0 : 1);
	}
}
