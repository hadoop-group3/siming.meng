package solution;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class MR2ToolRunner extends Configured implements Tool {

	public static class AverageReducer extends Reducer<Text, IntWritable, Text, DoubleWritable> {

		@Override
		public void reduce(Text key, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {

			long sum = 0, count = 0;

			for (IntWritable value : values) {
				sum += value.get();
				count++;
			}

			if (count != 0) {
				double result = (double) sum / (double) count;
				context.write(key, new DoubleWritable(result));
			}
		}
	}

	public static class LetterMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

		boolean caseSensitive = false;

		@Override
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

			String line = value.toString();

			for (String word : line.split("\\W+")) {
				if (word.length() > 0) {

					String letter;

					// use caseSensitive to convert to lower case when necessary
					if (caseSensitive)
						letter = word.substring(0, 1);
					else
						letter = word.substring(0, 1).toLowerCase();

					context.write(new Text(letter), new IntWritable(word.length()));
				}
			}
		}

		@Override
		public void setup(Context context) {

			// pull the caseSensitive property from job's configuration object
			Configuration conf = context.getConfiguration();
			caseSensitive = conf.getBoolean("caseSensitive", false);

		}
	}

	public static void main(String[] args) throws Exception {

		Configuration conf = new Configuration();

		/*
		 * set the caseSensitive configuration value for the job
		 * programmatically. Comment code out to set from the command line
		 * instead.
		 */
		// conf.setBoolean("caseSensitive", false);

		int exitCode = ToolRunner.run(conf, new MR2ToolRunner(), args);
		System.exit(exitCode);

	}

	@Override
	public int run(String[] args) throws Exception {

		if (args.length != 2) {
			System.out.printf("Usage: Provide -D <true|false> <input dir> <output dir>\n");
			System.exit(-1);
		}

		for (String arg : args)
			System.err.println(arg);

		Job job = Job.getInstance();
		job.setJarByClass(MR2ToolRunner.class);
		job.setJobName("ToolRunner");

		// setup input and output
		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		/*
		 * Specify the mapper and reducer classes.
		 */
		job.setMapperClass(LetterMapper.class);
		job.setReducerClass(AverageReducer.class);

		/*
		 * The mapper's output keys and values have different data types than
		 * the reducer's output keys and values. Therefore, you must call the
		 * setMapOutputKeyClass and setMapOutputValueClass methods.
		 */
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);

		/*
		 * Specify the job's output key and value classes.
		 */
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(DoubleWritable.class);

		/*
		 * Start the MapReduce job and wait for it to finish. If it finishes
		 * successfully, return 0. If not, return 1.
		 */
		boolean success = job.waitForCompletion(true);
		return (success ? 0 : 1);
	}
}
